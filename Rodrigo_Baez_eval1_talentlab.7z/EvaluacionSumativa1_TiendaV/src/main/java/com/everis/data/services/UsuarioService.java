package com.everis.data.services;

import java.util.ArrayList;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.stereotype.Service;
import com.everis.data.models.Usuario;
import com.everis.data.repositories.UsuarioRepository;

@Service
public class UsuarioService {

	private final  UsuarioRepository usuarioRepository;
	public UsuarioService(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository; 
	}
	
	public void crearUsuario(@Valid Usuario usuario) {			
		usuarioRepository.save(usuario);
	}
	
	public ArrayList<Usuario> findAll() {
		return usuarioRepository.findAll();
	}
	public void eliminarUsuario(Long id) {
		usuarioRepository.deleteById(id);		
	}
	public Usuario buscarUsuario(Long id) {
		Optional<Usuario> oUsuario = usuarioRepository.findById(id);
		if(oUsuario.isPresent()) {
			return oUsuario.get();
		}
		return null;
	}
	public void modificarUsuario(@Valid Usuario usuario) {	
		usuarioRepository.save(usuario);
	}
}
