package com.everis.data.repositories;

import java.util.ArrayList;
import org.springframework.data.repository.CrudRepository;
import com.everis.data.models.Venta;

public interface VentaRepository extends CrudRepository<Venta, Long>{

	ArrayList<Venta> findAll();
}
