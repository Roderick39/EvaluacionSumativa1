package com.everis.data.repositories;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;
import com.everis.data.models.Usuario;

public interface UsuarioRepository extends CrudRepository<Usuario, Long> {

	ArrayList<Usuario> findAll();
}
