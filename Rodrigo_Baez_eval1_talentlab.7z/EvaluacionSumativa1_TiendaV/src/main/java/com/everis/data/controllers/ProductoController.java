package com.everis.data.controllers;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.everis.data.models.Producto;
import com.everis.data.services.ProductoService;



@Controller
@RequestMapping("/producto")
public class ProductoController {

	private final ProductoService productoService;
	public ProductoController(ProductoService productoService) {
		this.productoService = productoService;
	}
	
	
	@RequestMapping("")
	public String index(@ModelAttribute("producto") Producto producto, Model model) {
		
		ArrayList<Producto> lista_productos = productoService.findAll();
		model.addAttribute("lista_productos",lista_productos);
		return "producto.jsp";
	}
	
	    //METODO PARA INSERTAR PRODUCTO
		@RequestMapping(value="/crear", method = RequestMethod.POST)
		public String crearProducto(@Valid @ModelAttribute("producto") Producto producto) {
				
			
				productoService.crearProducto(producto); 
				System.out.println("Producto creado:  " + producto.getId()); //obtengo id del producto, ya que es lo unico que me puede diferenciar un producto de otro
			                                                                //ya que pueden haber muchos productos de la misma categoria, marca o modelo
			return "redirect:/producto"; 
		}
		
		//METODO PARA ACTUALIZAR PRODUCTO
		@RequestMapping(value="/actualizar/{id}", method = RequestMethod.GET)
		public String actualizarProducto(@PathVariable("id") Long id, Model model) {
			System.out.println("El id del producto a actualizar es: "+id);
			Producto producto = productoService.buscarProducto(id);
			model.addAttribute("producto", producto);
			return "editarProducto.jsp";
		}
		
		
	
		//MÉTODO PARA MODIFICAR PRODUCTO
        @RequestMapping(value = "/modificar", method = RequestMethod.PUT)
        public String modificar(@Valid @ModelAttribute("producto") Producto producto) {
            System.out.println("id a modificar: " + producto.getId());
           
            //Validamos que no sean nulos los datos, y que cumplan requisitos para nombre y marca 
            if(!producto.getNombre().isBlank() && !producto.getCategoria().isBlank() && !producto.getMarca().isBlank() && !producto.getModelo().isBlank()) {
                if(producto.getNombre().length() < 4 || producto.getNombre().length() > 12) {
                    System.out.println("Error al ingresar nombre de producto (mínimo 4 y maximo 12)");
                }else if (producto.getMarca().length() < 3 || producto.getMarca().length() > 10 ){
                    System.out.println("Error al ingresar la marca del producto (mínimo 3 y maximo 10)");
                } else {
                    productoService.crearProducto(producto);
                    System.out.println("Producto creado:  " + producto.getId());
                }
            }else {
                System.out.println("Por favor ingrese informacion solicitada");
            }   
           
            return "redirect:/producto";
        }
		
		
		//METODO PARA ELIMINAR
		@RequestMapping(value="/eliminar/{id}", method = RequestMethod.DELETE)
		public String eliminarProducto(@PathVariable("id") Long id) {
			System.out.println("El id del producto a eliminar es: "+id);
			productoService.eliminarProducto(id);
			return "redirect:/producto";
		}
}
