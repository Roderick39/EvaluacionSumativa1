package com.everis.data.services;

import java.util.ArrayList;
import java.util.Optional;
import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.everis.data.models.Producto;
import com.everis.data.repositories.ProductoRepository;


@Service
public class ProductoService {

	private final  ProductoRepository productoRepository;
	public ProductoService(ProductoRepository productoRepository) {
		this.productoRepository = productoRepository; 
	}
	
	public void crearProducto(@Valid Producto producto) {			
		productoRepository.save(producto);
	}
	
	public ArrayList<Producto> findAll() {
		return productoRepository.findAll();
	}
	public void eliminarProducto(Long id) {
		productoRepository.deleteById(id);		
	}
	public Producto buscarProducto(Long id) {
		Optional<Producto> opProducto = productoRepository.findById(id);
		if(opProducto.isPresent()) {
			return opProducto.get();
		}
		return null;
	}
	public void modificarProducto(@Valid Producto producto) {	
		productoRepository.save(producto);
	}
}
